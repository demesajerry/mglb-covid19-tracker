<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vac_list extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('Clients_model');
		
	}

	public function index()
	{
		$this->isLogin_tagger();
		$this->isAllowed_Tagger();
		$this->load->model('Vac_list_model', '', TRUE);
		$this->load->model('General_model');
		$this->data['userdata'] = $this->session->userdata('tagger_logged_in');
		$this->data['content'] = 'vaccination/list';
		$selected_prov = '434';//LAGUNA as initial selected
		$selected_mun = '43411';//LB as initial selected
		$this->data['prov_list'] = $this->General_model->get_province();
		$this->data['municipality_list'] = $this->General_model->get_municipality($selected_prov);
		$this->data['brgy_list'] = $this->General_model->get_brgy($selected_mun);
		// $this->data['citymun_list'] = $this->Vac_list_model->get_citymun_list();
		// $this->data['clients_list'] = $this->Vac_list_model->get_clients_list();
		// $this->data['status_list'] = $this->Vac_list_model->get_status_list();
		// $this->data['est_list'] = $this->Vac_list_model->get_est_list();
		$this->load->view('template/tagger', $this->data);
	}

	public function view_details($userid= null, $action = null)
	{
		$this->isLogin_tagger();
		$this->isAllowed_Tagger();
		$this->load->model('General_model');
		$selected_prov = '434';//LAGUNA as initial selected
		$selected_mun = '43411';//LB as initial selected
		$this->data['userdata'] = $this->session->userdata('tagger_logged_in');
		$this->data['content'] = 'vaccination/view_details.php';
		$this->data['prov_list'] = $this->General_model->get_province();
		$this->data['municipality_list'] = $this->General_model->get_municipality($selected_prov);
		$this->data['brgy_list'] = $this->General_model->get_brgy($selected_mun);
		$this->data['userid'] = $userid;
		$this->data['action'] = $action;

		$this->load->view('template/tagger', $this->data);
	}

	public function ajax_list(){
		$this->isLogin_tagger();
		$this->isAllowed_Tagger();
		//$this->output->enable_profiler(TRUE);

		//do not search for verified
		$verified = 2;
		$active = 1;
    	$this->load->model('Vac_list_model');
        $list = $this->Vac_list_model->get_datatables($active,$verified);
        $data = array();
        $no = $_POST['start'];
        foreach ($list as $clients) {
            $no++;
            $row = array();
            $row[] = $clients->lname.', '.$clients->fname.' '.$clients->mname;
            $row[] = $clients->address.', '.$clients->brgyDesc.' '.$clients->citymunDesc;
            $row[] = $clients->birthday;
            $row[] = $clients->contact_number; 
            $row[] = $clients->date_reg; 

    		$actions='<a href="'.base_url().'Vac_list/view_details/'.$clients->id.'/1" ><i class="fa fa-eye"></i></a> | ';
    		$actions.='<a href="'.base_url().'Vac_list/view_details/'.$clients->id.'/2" ><i class="fa fa-stethoscope"></i></a> |';
    		if(in_array($this->session->userdata('tagger_logged_in')->access,array(1))){
			$actions.=' <a id="view_status" href="javascript:void(0)" title="View Status History" client_id="'.$clients->id.'")"><i class="fa fa-address-book fa-lg"></i></a>';
	    	}
            //actions
            $row[] = $actions;
            $data[] = $row;
        }
 
        $output = array(
                        "draw" => $_POST['draw'],
                        "recordsTotal" => $this->Vac_list_model->count_all($active,$verified),
                        "recordsFiltered" => $this->Vac_list_model->count_filtered($active,$verified),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }
	public function view_status()
	{
		$id = $this->input->post('id');

 		$this->load->model('Clients_model');
		$data = $this->Clients_model->view_status($id);

		echo json_encode($data);
	} 

	public function ajax_delete($id){
	    $this->Clients_model->delete_by_id($id);

 		$this->load->model('Admin_model');
 		$audit_data = new stdClass();
 		$audit_data->user_id = $this->session->userdata('logged_in')->userid;
 		$audit_data->client_id = $id;
 		$audit_data->datetime = date('Y-m-d H:i:s');
 		$audit_data->action_done = 'Client Deleted';
		$this->Admin_model->add($audit_data,'audit_trail');

	    echo json_encode($id);
  	}
}
