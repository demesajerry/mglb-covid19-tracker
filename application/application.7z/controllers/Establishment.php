<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Establishment extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->isLogin_est();
		//$this->output->enable_profiler(TRUE);
		//$this->load->model('patients_model', '', TRUE);
	}

	public function index(){
		$this->scan();
	}

	public function scan(){
		if($this->session->userdata('est_logged_in')->userid == 670){
			redirect(site_url("Est_reports/"));
		}else{
		$this->data['userdata'] = $this->session->userdata('est_logged_in');
		$this->data['content'] = 'establishment/scan.php';

		$this->load->view('template/establishment', $this->data);
		}
	}

	public function add_entry(){
		$this->load->model('Establishment_model');
		$this->load->model('General_model');
		date_default_timezone_set('Asia/Manila');
		$group_id = $this->input->post('group_id');
		$est_id = $this->input->post('est_id');
		$client_qrcode = $this->input->post('qrcode');
 		$userinfo = $this->General_model->check_qr_exist($client_qrcode,$group_id);

		$jsondata = new stdClass();
		$data = new stdClass();

		$jsondata->oddeven_exemption = $this->Establishment_model->get_by_id($est_id)->oddeven_exemption;
		$data->est_id = $est_id;
		$data->datetime =  date("Y-m-d H:i:s");
 		if(count($userinfo)>0){
			$data->sov =  $userinfo[0]->status;
			$data->client_id = $userinfo[0]->id;
 			$jsondata->userinfo = $userinfo[0];
			$jsondata->error_log = 0;
 			$track_id = $this->Establishment_model->add($data,'tracks');
 			if($userinfo[0]->status!=1){
				$data_alerts = new stdClass();
				$data_alerts->track_id = $track_id;
				$data_alerts->alert_status = $userinfo[0]->status;
				$data_alerts->checked = 0;
				$data_alerts->date = date('Y-m-d');
 				$this->Establishment_model->add($data_alerts,'alerts');
 			}
 		}else{
			$jsondata->error_log = 1;
 		}
 		
		header('Content-Type: application/json');
		echo json_encode( $jsondata );
 	}
 	
    public function forbidden()
	{
		$this->load->view('errors/index.html');
	} 
 }
