<?php
	class General_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
		}
		public function get_one_row($table,$id_name,$id){
			$this->db->select('*');
			$this->db->from($table);
			if($id!=''){
			$this->db->where($id_name,$id);
			}
			$query = $this->db->get('');
			$result = $query->result();
			if(count($result)!=0){
				return $result[0]; 
			}
			else{
				return false;
			}		
		}
		public function list($table){
			$this->db->select('*');
			$this->db->from($table);
			$query = $this->db->get('');
			$result = $query->result();
			return $result; 
		}
		public function get_province(){
			$this->db->select('provDesc,provCode');
			$this->db->from('refprovince');
			return $this->db->get()->result_object(); 
		}
		public function get_municipality($provCode){
			$this->db->select('citymunDesc,citymunCode,provCode');
			$this->db->from('refcitymun');
			$this->db->where('provCode', $provCode); 
			return $this->db->get()->result_object(); 
		}
		public function get_brgy($citymunCode){
			$this->db->select('brgyDesc,brgyCode,citymunCode');
			$this->db->from('refbrgy');
			$this->db->where('citymunCode', $citymunCode); 
			return $this->db->get()->result_object(); 
		}
		public function get_hmo(){
			$this->db->select('*');
			$this->db->from('hmo');
			return $this->db->get()->result_object(); 
		}
		public function check_qr_exist($qrcode,$group_id){
			$this->db->select('a.id, a.fname, a.lname , a.oddeven_exemption, b.brgyDesc,c.citymunDesc, TIMESTAMPDIFF(YEAR, a.birthday, CURDATE()) AS age, a.sex,a.status, b.brgyCode, b.citymunCode, d.template, a.active, group_id, a.apor');
			$this->db->from('clients a');
			$this->db->join('refbrgy b','b.brgyCode = a.brgyCode');
			$this->db->join('refcitymun c','c.citymunCode = a.citymunCode');
			$this->db->join('covid_status d','d.c_status_id = a.status');
        	$this->db->join('(select client_id, group_id from oddeven_exemption where group_id = '.$group_id.') e','e.client_id = a.id','left');
			$this->db->where('qrcode', $qrcode); 
			$query = $this->db->get();
			//echo $this->db->last_query();

			$result = $query->result();
			return $result; 
		}

		public function tagger_qr_exist($qrcode){
			$this->db->select('a.id, a.fname, a.lname , a.oddeven_exemption, b.brgyDesc,c.citymunDesc, TIMESTAMPDIFF(YEAR, a.birthday, CURDATE()) AS age, a.sex,a.status, b.brgyCode, b.citymunCode, d.template, a.active, a.apor');
			$this->db->from('clients a');
			$this->db->join('refbrgy b','b.brgyCode = a.brgyCode');
			$this->db->join('refcitymun c','c.citymunCode = a.citymunCode');
			$this->db->join('covid_status d','d.c_status_id = a.status');
			$this->db->where('qrcode', $qrcode); 
			$query = $this->db->get();
			//echo $this->db->last_query();

			$result = $query->result();
			return $result; 
		}

		public function client_list($search,$group_id){
			$this->db->select('concat(a.lname,", ",a.fname," ",a.mname) as fullname, a.id');
			$this->db->from('clients a');
			if($group_id!=''){
			$this->db->join('(select client_id from oddeven_exemption where group_id = '.$group_id.') b','b.client_id = a.id', 'left');
			$this->db->where('b.client_id IS NULL');
			}
			if($search!=''){
				$this->db->group_start();
					$this->db->like('concat_ws(" ",a.lname,a.fname,a.mname)',$search);
					$this->db->or_like('concat_ws(" ",a.fname,a.lname,a.mname)',$search);
					$this->db->or_like('concat(a.lname,", ",a.fname," ",a.mname)',$search);
				$this->db->group_end();
			}
			$this->db->limit('20');
			$query = $this->db->get('');
			$result = $query->result();
			//echo $this->db->last_query();

			return $result; 
		}

		public function est_list($search){
			$this->db->select('*');
			$this->db->from('establishments');
			if($search!=''){
				$this->db->like('name',$search);
			}
			$this->db->group_by('group_id');
			$this->db->limit('20');
			$query = $this->db->get('');
			$result = $query->result();
			//echo $this->db->last_query();

			return $result; 
		}

		public function not_member($search,$est_id){
			$this->db->select('*');
			$this->db->from('establishments');
			$this->db->where('group_id !=',$est_id);
			if($search!=''){
				$this->db->like('name',$search);
			}
			$this->db->limit('20');
			$query = $this->db->get('');
			$result = $query->result();
			//echo $this->db->last_query();

			return $result; 
		}

		public function link_tree(){
			$this->db->select('*');
			$this->db->from('link');
			$this->db->where('status',0);
			$this->db->order_by('link_id','ASC');
			return $this->db->get()->result_object(); 
		}

		public function update($data,$where,$table){
			foreach($where as $key=>$val){
				$this->db->where($key,$val); 
			}
			$this->db->update($table, $data); 
			//echo $this->db->last_query();
		}

		public function add($data,$table){
			$this->db->insert($table, $data);
			$insert_id = $this->db->insert_id();
   			return  $insert_id;
		}
	}
?>

