<?php
	class Vaccination_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
		}

		public function get_details($where){
			$this->db->select('a.*,b.*,c.*');
			$this->db->from('clients a');
			$this->db->join('vaccination b','b.userid = a.id','LEFT');
			$this->db->join('post_vaccination c','c.userid = a.id','LEFT');
			foreach($where as $key=>$val){
				$this->db->where($key, $val); 
			}
			$query = $this->db->get();
			//echo $this->db->last_query();

			$result = $query->result();
			return $result; 
		}

		public function update($data, $where, $table){
			$update = new stdClass();
			foreach($data as $key=>$val){
				if ($this->db->field_exists($key, $table)){
					$update->{$key} = $val;
				}
			}
			$this->db->set($update);
			foreach($where as $key=>$val){
				$this->db->where($key,$val);
			}
			$this->db->update($table);
			return true;
		}

		public function add($data,$table){
			$add = new stdClass();
			foreach($data as $key=>$val){
				if ($this->db->field_exists($key, $table)){
					$add->{$key} = $val;
				}
			}
			$this->db->insert($table, $add);
			$insert_id = $this->db->insert_id();
   			return  $insert_id;
		}
	}
?>

