<?php
	class Reports_model extends CI_Model
	{
		public function __construct()
		{
			parent::__construct();
		}

		public function get_tracks($data){
			$this->db->select('b.fname, b.lname, b.mname, b.contact_number, b.address, d.brgyDesc, e.citymunDesc, c.name as est_visited, a.datetime,a.sov as sov_id, b.status as status_id, f.c_classification as status, ff.c_classification as sov ');
			$this->db->from('tracks a');
			$this->db->join('clients b', 'b.id = a.client_id');
			$this->db->join('establishments c', 'c.id = a.est_id');
			$this->db->join('refbrgy d', 'd.brgyCode = b.brgyCode');
			$this->db->join('refcitymun e', 'e.citymunCode = b.citymunCode');
			$this->db->join('covid_status f', 'f.c_status_id = b.status','left');
			$this->db->join('covid_status ff', 'ff.c_status_id = a.sov','left');
			if($data->client_id){
				$this->db->where("a.client_id", $data->client_id);
			} 
			if($data->est_id){
				$this->db->where("a.est_id", $data->est_id);
			}
			if($data->date_from != ""){
				$date_from = date('Y-m-d H:i:s', strtotime($data->date_from." 00:00:00")); 
				$this->db->WHERE('a.datetime >=',$date_from);
			}
			if($data->date_to != ""){
				$date_to = date('Y-m-d H:i:s', strtotime($data->date_to." 23:59:59"));
				$this->db->where('a.datetime <=', $date_to);
			}
			if($data->alert == 1){
				$this->db->where_in('a.sov',["2","3","5","6"]);
			}
			if($data->alert == 0){
				$this->db->where_in('a.sov',["1","4"]);
			}
			//$query = $this->db->get('');
			//echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}

		public function get_vac($data){
			$this->db->select('a.*,b.*,c.provDesc, d.citymunDesc, e.brgyDesc, DATE_FORMAT(a.birthday, "%m/%d/%Y") as birthday, f.provDesc as employer_prov_desc, TIMESTAMPDIFF(YEAR, a.birthday, CURDATE()) AS age');
			$this->db->from('clients a');
			$this->db->join('vaccination b', 'b.userid = a.id', 'INNER');
			$this->db->join('refprovince c', 'c.provCode = a.provCode', 'INNER');
			$this->db->join('refcitymun d', 'd.citymunCode = a.citymunCode', 'INNER');
			$this->db->join('refbrgy e', 'e.brgyCode = a.brgyCode', 'INNER');
			$this->db->join('refprovince f', 'f.provCode = b.employer_prov', 'LEFT');

			if($data->date_reg!=''){
				$this->db->where('b.date_reg >', $data->date_reg);
			}
			if($data->min_age!=''){
				$this->db->where('TIMESTAMPDIFF(YEAR, a.birthday, CURDATE()) >=', $data->min_age);
			}
			if($data->max_age!=''){
				$this->db->where('TIMESTAMPDIFF(YEAR, a.birthday, CURDATE()) <=', $data->max_age);
			}
			if($data->category!=''){
				$this->db->where_in('b.category', $data->category);
			}
			if($data->brgyCode!=''){
				$this->db->where_in('a.brgyCode', $data->brgyCode);
			}
			if($data->with_comorbidity!=''){
				$this->db->where('b.with_comorbidity', $data->with_comorbidity);
			}


			// $query = $this->db->get('');
			// echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}

		public function get_mho($data){
			$this->db->select('b.fname, b.lname, b.mname, b.contact_number, b.address, d.brgyDesc, e.citymunDesc, c.name as est_visited, a.datetime,a.sov as sov_id, b.status as status_id, f.c_classification as status, ff.c_classification as sov, TIMESTAMPDIFF(YEAR, b.birthday, CURDATE()) AS age, b.sex ');
			$this->db->from('tracks a');
			$this->db->join('clients b', 'b.id = a.client_id');
			$this->db->join('establishments c', 'c.id = a.est_id');
			$this->db->join('refbrgy d', 'd.brgyCode = b.brgyCode');
			$this->db->join('refcitymun e', 'e.citymunCode = b.citymunCode');
			$this->db->join('covid_status f', 'f.c_status_id = b.status','left');
			$this->db->join('covid_status ff', 'ff.c_status_id = a.sov','left');
			$this->db->where("a.est_id", $data->est_id);
			if($data->date_from != ""){
				$date_from = date('Y-m-d H:i:s', strtotime($data->date_from." 00:00:00")); 
				$this->db->WHERE('a.datetime >=',$date_from);
			}
			if($data->date_to != ""){
				$date_to = date('Y-m-d H:i:s', strtotime($data->date_to." 23:59:59"));
				$this->db->where('a.datetime <=', $date_to);
			}
			$this->db->order_by("a.id",'DESC');
			//$query = $this->db->get('');
			//echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}

		public function get_health_dec($data){
			$this->db->select('DATE_FORMAT(a.date_changed, "%M&nbsp;%d,%Y&nbsp;%H:%i:%s") as date_changed, DATE_FORMAT(a.onset_date, "%M&nbsp;%d,%Y") as onset_date, DATE_FORMAT(a.date_recovered, "%M&nbsp;%d,%Y") as date_recovered, concat(b.lname,", ",b.fname," ", b.mname) as fullname, b.contact_number, b.address,c.c_symptom as symptom, d.brgyDesc, e.citymunDesc');
			$this->db->from('client_symptoms a');
			$this->db->join('clients b', 'b.id = a.client_id');
			$this->db->join('symptoms c', 'c.c_symptom_id = a.symptoms');
			$this->db->join('refbrgy d', 'd.brgyCode = b.brgyCode');
			$this->db->join('refcitymun e', 'e.citymunCode = b.citymunCode');
			if($data->client_id){
				$this->db->where("a.client_id", $data->client_id);
			} 
			if($data->date_from != ""){
				$this->db->WHERE('a.onset_date >=',$data->date_from);
			}
			if($data->date_to != ""){
				$this->db->where('a.onset_date <=', $data->date_to);
			}
			if($data->ddate_from != ""){
				$ddate_from = date('Y-m-d H:i:s', strtotime($data->ddate_from." 00:00:00")); 
				$this->db->WHERE('a.date_changed >=',$ddate_from);
			}
			if($data->ddate_to != ""){
				$ddate_to = date('Y-m-d H:i:s', strtotime($data->ddate_to." 23:59:59")); 
				$this->db->where('a.date_changed <=', $ddate_to);
			}
			//$query = $this->db->get('');
			//echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}

		public function get_close_contact($data){
			$this->db->select('DATE_FORMAT(a.date_added, "%M&nbsp;%d,%Y&nbsp;%H:%i:%s") as date_added, DATE_FORMAT(a.closed_contact_date, "%M&nbsp;%d,%Y") as closed_contact_date, concat(b.lname,", ",b.fname," ", b.mname) as fullname, b.contact_number, b.address, d.brgyDesc, e.citymunDesc');
			$this->db->from('closed_contact_tbl a');
			$this->db->join('clients b', 'b.id = a.closed_client_id');
			$this->db->join('refbrgy d', 'd.brgyCode = b.brgyCode');
			$this->db->join('refcitymun e', 'e.citymunCode = b.citymunCode');
			if($data->client_id){
				$this->db->where("a.client_id", $data->client_id);
			} 
			if($data->date_from != ""){
				$this->db->WHERE('a.closed_contact_date >=',$data->date_from);
			}
			if($data->date_to != ""){
				$this->db->where('a.closed_contact_date <=', $data->date_to);
			}
			if($data->ddate_from != ""){
				$ddate_from = date('Y-m-d H:i:s', strtotime($data->ddate_from." 00:00:00")); 
				$this->db->WHERE('a.date_added >=',$ddate_from);
			}
			if($data->ddate_to != ""){
				$ddate_to = date('Y-m-d H:i:s', strtotime($data->ddate_to." 23:59:59")); 
				$this->db->where('a.date_added <=', $ddate_to);
			}
			//$query = $this->db->get('');
			//echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}

		public function get_age_bracket($data){
			$this->db->select('DATE(a.datetime) as date,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) <= 20, 1,0)) AS ageb20,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) >= 21 AND TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) <=29, 1,0)) AS age2129,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) >= 30 AND TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) <=39, 1,0)) AS age3039,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) >= 40 AND TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) <=49, 1,0)) AS age4049,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) >= 50 AND TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) <=59, 1,0)) AS age5059,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) >= 60 AND TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) <=65, 1,0)) AS age6065,
							sum(IF(TIMESTAMPDIFF(YEAR, b.birthday ,a.datetime) >= 66, 1,0)) AS ageg66,
							sum(if(a.sov != 1, 1,0)) as alert_logs, 
							count(a.id) as total');
			$this->db->from('tracks a');
			$this->db->join('clients b', 'b.id = a.client_id');
			$this->db->join('establishments c', 'c.id = a.est_id');
			if($data->est_id){
				$this->db->where("a.est_id", $data->est_id);
			}
			if($data->date_from != ""){
				$date_from = date('Y-m-d H:i:s', strtotime($data->date_from." 00:00:00")); 
				$this->db->WHERE('a.datetime >=',$date_from);
			}
			if($data->date_to != ""){
				$date_to = date('Y-m-d H:i:s', strtotime($data->date_to." 23:59:59"));
				$this->db->where('a.datetime <=', $date_to);
			}
			$this->db->WHERE('b.id !=','14261');
			$this->db->group_by('DATE(a.datetime)');
			$this->db->order_by('DATE(a.datetime)','ASC');
			//$query = $this->db->get('');
			//echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}

		public function get_est_logs($data){
			$this->db->select('c.name as scanner_name, DATE(a.datetime) as date_log,
				sum(if(a.sov = 1 OR a.sov = 4, 1,0)) as normal_logs, 
				sum(if(a.sov != 1, 1,0)) as alert_logs, 
				c.name, a.datetime ');
			$this->db->from('tracks a');
			$this->db->join('establishments c', 'c.id = a.est_id');

			if($data->est_id){
				$this->db->where("a.est_id", $data->est_id);
			}
			if($data->date_from != ""){
				$date_from = date('Y-m-d H:i:s', strtotime($data->date_from." 00:00:00")); 
				$this->db->WHERE('a.datetime >=',$date_from);
			}
			if($data->date_to != ""){
				$date_to = date('Y-m-d H:i:s', strtotime($data->date_to." 23:59:59"));
				$this->db->where('a.datetime <=', $date_to);
			}
			$this->db->WHERE('c.id !=','14261');
			$this->db->group_by('DATE(a.datetime), a.est_id');
			$this->db->order_by('normal_logs','DESC');
			//$query = $this->db->get('');
			//echo $this->db->last_query();

			return $this->db->get()->result_object(); 
		}
	}
?>

