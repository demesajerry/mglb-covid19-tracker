<style>
  .ui-datepicker-calendar {
        display: none;
    }
    .box-tools{
        width: 900px;
        padding: 0;
    }
    .filters{
        padding: 0;
    }
    .txt-bottom{
        vertical-align:bottom !important;
    }
    .table-hover>tbody>tr.warning:hover>td, .table-hover>tbody>tr.warning:hover>th, .table-hover>tbody>tr:hover>.warning, .table-hover>tbody>tr>td.warning:hover, .table-hover>tbody>tr>th.warning:hover {
      background-color: #FFFF66 !important;
    }
    .table>tbody>tr.warning>td{
      background-color: #FFFF99 !important;
    }
</style>
<div class="content-wrapper">
<!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
        Vaccination
        <small></small>
        </h1>
        <ol class="breadcrumb">
        <li><a href="#"> Reports</a></li>
        <li class="active">TRACKS</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                    <div class="col-xs-12">
                      <form id="form1" method="post">
                        <div class="col-md-1"> 
                          <label>With Comorbidity</label>
                          <select id="with_comorbidity" name="with_comorbidity" class="form-control select2" >
                              <option value="">ALL</option>
                              <option value="01_Yes">With Comorbidity</option>
                              <option value="02_None">None</option>
                           </select>                        
                         </div>
                        <div class="col-md-2">
                          <label>Brgy:</label>
                          <select id="brgyCode" name="brgyCode[]" class="form-control select2" multiple="multiple">
                            <option value="">ALL</option>
                            <?php foreach($brgy_list as $val){ ?>
                            <!--Initial selected is LAGUNA ProvCode=0434-->
                              <option value="<?= $val->brgyCode ?>"> <?= $val->brgyDesc ?></option>
                            <?php } ?>
                          </select>
                        </div> 
                        <div class="col-md-2"> 
                          <label>Category</label>
                            <select id="category" name="category[]" class="form-control select2" multiple="multiple">
                              <option value="">Select Category</option>
                              <option value="">ALL</option>
                              <option value="06_Other">Others</option>
                              <option value="01_Health_Care_Worker">Health Care Worker</option>
                              <option value="02_Senior_Citizen/A">Senior Citizen</option>
                              <option value="03_Indigent/A">Indigent</option>
                              <option value="04_Uniformed_Personnel">Uniformed Personnel</option>
                              <option value="05_Essential_Worker">Essential Worker</option>
                             </select>
                        </div>
                        <div class="col-md-1">
                        <label>Min AGE: </label> 
                          <input type="text" name="min_age" class="form-control" placeholder="Date" />
                        </div>
                        <div class="col-md-1">
                        <label>Max AGE: </label> 
                          <input type="text" name="max_age" class="form-control" placeholder="Date" />
                        </div>

                        <div class="col-md-2">
                        <label>Date: </label> 
                        <input type="date" name="date" class="form-control" placeholder="Date" />
                        </div>
                        <div class="col-md-2">
                        <label>Time: </label> 
                        <input type="time" name="time" class="form-control" placeholder="Time" />
                        </div>
                        <div class="col-md-1"><br>
                          <button class="btn btn-primary" id="generate">Generate</button>
                        </div>
                      </form>
                     </div>
                   </div>
                </div>

                <div class="box">
                    <div class="box-header">
                    <h3 class="box-title date_title">CLIENT COUNT</h3>
                    </div>
                <div class="box-body table-responsive">
                  <div id="toprint">
                  <table class="table table-striped table-bordered table-hover" id="viewresult">
                    <thead id="thead">
                      <tr>
                        <td>Category</td>
                        <td>Category ID</td>
                        <td>ID #</td>
                        <td>Philhealth ID</td>
                        <td>PWD ID</td>
                        <td>Last Name</td>
                        <td>First Name</td>
                        <td>Middle Name</td>
                        <td>Suffix</td>
                        <td>Contact #</td>
                        <td>Address</td>
                        <td>Region</td>
                        <td>Province</td>
                        <td>Municipality</td>
                        <td>Barangay</td>
                        <td>Sex</td>
                        <td>Birthday</td>
                        <td>Civil Status</td>
                        <td>Employment Status</td>
                        <td>Direct Contact</td>
                        <td>Profession</td>
                        <td>Employer</td>
                        <td>HUC</td>
                        <td>E-Address</td>
                        <td>E-#</td>
                        <td>Pregnancy</td>
                        <td>Drug</td>
                        <td>Food</td>
                        <td>Insect</td>
                        <td>Latex</td>
                        <td>Mold</td>
                        <td>Pet</td>
                        <td>Pollen</td>
                        <td>Comorbidity</td>
                        <td>Hypertension</td>
                        <td>Heart</td>
                        <td>Kidney</td>
                        <td>Diabetes</td>
                        <td>Asthma</td>
                        <td>Immuno</td>
                        <td>Cancer</td>
                        <td>Others</td>
                        <td>Covid19</td>
                        <td>Date</td>
                        <td>Class</td>
                        <td>Consent</td>
                      </tr>
                    </thead>
                    <tbody id="tbody">
                    </tbody>
                    <tfoot id="tfoot">
                    </tfoot>
                  </table>
                </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
$(document).ready(function() {
$('#loader').hide();
var client;
function get_data(){
$.ajax({
  type: "POST",
  url: "<?php echo base_url().'reports/get_vac'; ?>",
  data: $("#form1").serializeArray(),
  beforeSend: function() {
    tr = `<tr id="loader">
                <td colspan="41">
                  <div class="callout callout-info"><p><i class="fa fa-circle-o-notch fa-spin"></i> Loading Data...</p></div>
                </td>
            </tr>`;
    $('#tbody').html(tr);
  },
  complete: function(){
    $('#loader').hide();
  },
  //data:formData,
    success: function(data){ 
        $('.date_title').html(`Registered from ${data.date_reg}`);
      var tr ='',total_male=0,total_female=0,total_all=0,tfoot,fullname,datetime;
      table.clear();
       $.each(data.tracks, function(key, val){
        province = `_0${val.provCode}_${val.provDesc}`;
        employer_prov = `_${val.provCode} - ${val.employer_prov_desc}`;
        citymun = `_${val.citymunCode}_${val.citymunDesc}`;
        brgy = `_${val.brgyCode}_${val.brgyDesc}`;
        address = `${val.address} ${val.brgyDesc} ${val.citymunDesc}`;
        sex = val.sex==0?`01_Female`:`02_Male`;
        bady = convert_datetime(val.birthday);
         var rowNode = table.row.add([ val.category,
                      val.category_id,
                      val.category_id_number,
                      val.philhealth_id,
                      val.pwd_id,
                      val.lname,
                      val.fname,
                      val.mname,
                      val.suffix,
                      val.contact_number,
                      val.address,
                      'CALABARZON',
                      province,
                      citymun,
                      brgy,
                      sex,
                      val.birthday,
                      val.civil_status,
                      val.employment_status,
                      val.direct_contact,
                      val.profession,
                      val.employer_name,
                      employer_prov,
                      val.employer_add,
                      val.employer_no,
                      val.pregnancy_status,
                      val.drug,
                      val.food,
                      val.insect,
                      val.latex,
                      val.mold,
                      val.pet,
                      val.pollen,
                      val.with_comorbidity,
                      val.hypertension,
                      val.heart,
                      val.kidney,
                      val.diabetes,
                      val.asthma,
                      val.immuno,
                      val.cancer,
                      val.other,
                      val.covid19,
                      val.covid19_date,
                      val.covid19_class,
                      val.consent,
                      val.date_reg,
                      val.date_update,
                      val.update_by,
                      val.vaccine
                  ]).draw().node();
         // if(){
         //    $( rowNode ).addClass('warning'); 
         //  }
        })         
    }
});
}

$('#generate').click(function(e){
  e.preventDefault();
  get_data();
})

$('.daterange').on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('Y-MM-D') + ' - ' + picker.endDate.format('Y-MM-D'));
  });

    var table = $('#viewresult').DataTable({
    responsive: true,
    "aLengthMenu": [[5, 10, 20, -1], [5, 10, 20, "All"]],
    dom: 'Blfrtip',
    "iDisplayLength": 5,
    "aaSorting": [],
    buttons:[
              {
                extend: 'excelHtml5',
                title: 'MGLB-COVID19-TRACKER Report',
              },
              {
                extend: 'print',
                title: 'MGLB-COVID19-TRACKER Report',
              }
            ]
    });

 $("#client_id").select2({
  ajax: { 
   url: "<?php echo base_url(); ?>General/get_clients",
   type: "post",
   dataType: 'json',
   delay: 250,
   data: function (params) {
    return {
      search: params.term, // search term
      group_id: ''
    };
   },
processResults: function (data) {
  //add ALL to array
  if(data.length >= 20 ){
  data.unshift({
    fullname : 'ALL', 
    id : ''
  });
}
            return {
                results: $.map(data, function (item) {
                    return {
                        text: item.fullname,
                        id: item.id
                    }
                })
            };
        }
    }
 });

 $("#est_id").select2({
  ajax: { 
   url: "<?php echo base_url(); ?>General/get_not_member",
   type: "post",
   dataType: 'json',
   delay: 250,
   data: function (params) {
    return {
      search: params.term, // search term
      est_id: '', // search term
    };
   },
  processResults: function (data) {
    //add ALL to array
    if(data.length >= 20 ){
      data.unshift({
        name : 'ALL', 
        id : ''
      });
    }
      return {
        results: $.map(data, function (item) {
          return {
            text: item.name,
            id: item.id
          }
        })
      };
    }
  }
 });
});
</script>
